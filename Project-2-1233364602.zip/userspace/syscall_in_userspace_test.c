// File: userspace/syscall_in_userspace_test.c

/* This is a template file for testing custom syscall. */
#include <unistd.h>

int main() {
	syscall(463);
	return 0;
}
